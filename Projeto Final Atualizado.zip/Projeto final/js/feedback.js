/* ===========================================
   CDKL's - feedback.js
=========================================== */

// 1. Controle de Acessibilidade (Sincronização da Fonte)
const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

// 2. Proteção de Rota / Verificação de Sessão
const sessao = JSON.parse(localStorage.getItem("sessaoCDKLS"));
if (!sessao) {
    window.location.href = "login.html";
}

// 3. Atualização Dinâmica do Valor do Slider (Satisfação)
const sliderSatisfacao = document.getElementById("satisfacao");
const labelSatisfacao = document.getElementById("valorSatisfacao");

if (sliderSatisfacao && labelSatisfacao) {
    sliderSatisfacao.addEventListener("input", (e) => {
        labelSatisfacao.textContent = e.target.value;
    });
}

// 4. Envio e Validação do Formulário
const form = document.getElementById("formFeedback");
const toast = document.getElementById("toast");

function mostrarAviso(mensagem) {
    toast.textContent = mensagem;
    toast.style.display = "block";
    setTimeout(() => {
        toast.style.display = "none";
    }, 3000);
}

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const satisfacao = sliderSatisfacao.value;
    const categoria = document.getElementById("categoria").value;
    const compraria = document.querySelector('input[name="compraria"]:checked').value;
    
    // Captura dos Checkboxes Selecionados
    const checks = document.querySelectorAll('.checkGroup input:checked');
    const interesses = [];
    checks.forEach(item => {
        interesses.push(item.value);
    });

    // Captura e Higienização do Comentário
    const comentario = document.getElementById("comentario").value.trim();

    // Validação de segurança: Evitar comentários vazios ou curtos demais
    if (comentario.length < 10) {
        mostrarAviso("Por favor, escreva um comentário com pelo menos 10 caracteres.");
        return;
    }

    // Montagem do objeto de feedback enriquecido com dados do usuário logado
    const feedback = {
        usuario: sessao.nome,
        email: sessao.email || "Não informado",
        satisfacao: Number(satisfacao),
        categoria,
        compraria,
        interesses,
        comentario,
        dataEnvio: new Date().toLocaleDateString("pt-BR")
    };

    // Salva no banco local
    localStorage.setItem("feedbackCDKLS", JSON.stringify(feedback));

    // Redireciona para a página de visualização de dados
    window.location.href = "visualizacao.html";
});