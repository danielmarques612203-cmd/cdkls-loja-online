/* ===========================================
   CDKL's - login.js
=========================================== */

// 1. Controle de Acessibilidade (Sincronização da Fonte)
const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

// 2. Verificação de Sessão Pré-existente (Evita login duplo)
if (localStorage.getItem("sessaoCDKLS")) {
    window.location.href = "dashboard.html";
}

const form = document.getElementById("formLogin");
const toast = document.getElementById("toast");

/* ===========================================
   FUNÇÃO AUXILIAR: EXIBIR NOTIFICAÇÃO
=========================================== */
function mostrarToast(msg, tipo = "erro") {
    toast.textContent = msg;
    toast.className = `toast ${tipo} mostrar`; // Adiciona a classe que ativa a opacidade no CSS

    setTimeout(() => {
        toast.classList.remove("mostrar"); // Esconde via CSS suavemente
        
        // Aguarda a transição terminar antes de limpar o texto
        setTimeout(() => {
            toast.textContent = "";
            toast.className = "toast";
        }, 300);
    }, 3000);
}

/* ===========================================
   EVENTO DE SUBMIT DO FORMULÁRIO
=========================================== */
form.addEventListener("submit", (e) => {
    e.preventDefault();

    const loginDigitado = document.getElementById("login").value.trim();
    const senhaDigitada = document.getElementById("senha").value.trim();

    // Recupera do LocalStorage a lista de usuários cadastrados
    const usuariosCadastrados = JSON.parse(localStorage.getItem("usuariosCDKLS")) || [];

    // Procura por correspondência exata de credenciais
    // Aceita tanto se o campo salvo for chamado de 'login' quanto se for 'usuario'/'email'
    const usuarioValido = usuariosCadastrados.find(u => 
        (u.login === loginDigitado || u.usuario === loginDigitado || u.email === loginDigitado) && 
        u.senha === senhaDigitada
    );

    if (!usuarioValido) {
        mostrarToast("Usuário, e-mail ou senha inválidos.", "erro");
        return;
    }

    // Cria a sessão com os dados do usuário validado
    localStorage.setItem("sessaoCDKLS", JSON.stringify(usuarioValido));

    mostrarToast("Login realizado com sucesso! Redirecionando...", "sucesso");

    // Redireciona para o painel principal após um pequeno delay para o usuário ler o sucesso
    setTimeout(() => {
        window.location.href = "dashboard.html";
    }, 1500);
});