/* ===========================================
   CDKL's - visualizacao.js
=========================================== */

// 1. Controle de Acessibilidade (Sincronização da Fonte)
const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

// 2. Proteção de Rota
const sessao = JSON.parse(localStorage.getItem("sessaoCDKLS"));
if (!sessao) {
    window.location.href = "login.html";
}

// 3. Captura e Renderização do Feedback
const feedback = JSON.parse(localStorage.getItem("feedbackCDKLS"));
const dadosContainer = document.getElementById("dados");

if (!feedback) {
    dadosContainer.innerHTML = `
        <div class="item">
            <strong>Status:</strong> Nenhum feedback registrado neste navegador.
        </div>
    `;
} else {
    // Tratamento de segurança para o array de interesses (evita quebras se vazio)
    const itensInteresse = feedback.interesses && feedback.interesses.length > 0 
        ? feedback.interesses.join(", ") 
        : "Nenhum ponto selecionado";

    dadosContainer.innerHTML = `
        <div class="item">
            <strong>Cliente:</strong>
            <span>${feedback.usuario || sessao.nome}</span>
        </div>

        <div class="item">
            <strong>Data do Envio:</strong>
            <span>${feedback.dataEnvio || new Date().toLocaleDateString("pt-BR")}</span>
        </div>

        <div class="item">
            <strong>Nível de Satisfação:</strong>
            <span>${feedback.satisfacao} / 10</span>
        </div>

        <div class="item">
            <strong>Categoria Favorita:</strong>
            <span>${feedback.categoria}</span>
        </div>

        <div class="item">
            <strong>Compraria Novamente?</strong>
            <span>${feedback.compraria}</span>
        </div>

        <div class="item">
            <strong>Pontos de Destaque:</strong>
            <span>${itensInteresse}</span>
        </div>

        <div class="item comentarioBox">
            <strong>Comentário Registrado:</strong>
            <p>${feedback.comentario || "Nenhum comentário adicional informado."}</p>
        </div>
    `;
}