/* ===========================================
   CDKL's - dashboard.js
=========================================== */

// 1. Controle de Acessibilidade (Mantém o tamanho da fonte escolhido na Home)
const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

// 2. Verificação de Sessão Segura (Sem redundâncias)
const usuarioLogado = JSON.parse(localStorage.getItem("sessaoCDKLS"));

if (!usuarioLogado) {
    // Se não houver sessão ativa, expulsa para a página de login
    window.location.href = "login.html";
} else {
    // Se houver, injeta o nome do usuário na interface
    document.getElementById("nomeUsuario").textContent = usuarioLogado.nome;
}

/* ===========================================
   AÇÃO DE LOGOUT
=========================================== */
document.getElementById("logout").addEventListener("click", () => {
    // Destrói a sessão atual
    localStorage.removeItem("sessaoCDKLS");
    
    // Redireciona para o login
    window.location.href = "login.html";
});