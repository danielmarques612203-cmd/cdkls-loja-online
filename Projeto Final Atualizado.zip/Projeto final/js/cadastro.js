/* ===========================================
   CDKL's - Cadastro (Versão Corrigida)
=========================================== */

const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

const form = document.getElementById("formCadastro");
const toast = document.getElementById("toast");

function mostrarToast(mensagem, tipo = "erro") {
    if (!toast) {
        alert(mensagem); // Fallback caso o elemento toast não seja encontrado no HTML
        return;
    }
    toast.textContent = mensagem; 
    toast.className = `toast ${tipo} mostrar`;

    setTimeout(() => {
        toast.classList.remove("mostrar");
        setTimeout(() => {
            toast.textContent = "";
            toast.className = "toast";
        }, 300);
    }, 3000);
}

/* Validações */
function validarNome(nome) {
    nome = nome.trim();
    if (nome.length < 15 || nome.length > 80) return false;
    const regex = /^[A-Za-zÀ-ÿ\s]+$/;
    if (!regex.test(nome)) return false;
    const partes = nome.split(" ");
    return partes.length >= 2;
}

function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, "");
    if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;

    let soma = 0;
    for (let i = 0; i < 9; i++) {
        soma += Number(cpf.charAt(i)) * (10 - i);
    }
    let resto = (soma * 10) % 11;
    if (resto === 10) resto = 0;
    if (resto !== Number(cpf.charAt(9))) return false;

    soma = 0;
    for (let i = 0; i < 10; i++) {
        soma += Number(cpf.charAt(i)) * (11 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10) resto = 0;

    return resto === Number(cpf.charAt(10));
}

/* Máscaras */
const cpfInput = document.getElementById("cpf");
if (cpfInput) {
    cpfInput.addEventListener("input", () => {
        let valor = cpfInput.value.replace(/\D/g, "").substring(0, 11);
        valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
        valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
        valor = valor.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
        cpfInput.value = valor;
    });
}

const cepInput = document.getElementById("cep");
if (cepInput) {
    cepInput.addEventListener("input", () => {
        let valor = cepInput.value.replace(/\D/g, "").substring(0, 8);
        valor = valor.replace(/(\d{5})(\d)/, "$1-$2");
        cepInput.value = valor;
    });

    /* ViaCEP */
    cepInput.addEventListener("blur", async () => {
        const cep = cepInput.value.replace(/\D/g, "");
        if (cep.length !== 8) return;

        try {
            const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            if (!resposta.ok) throw new Error();

            const dados = await resposta.json();
            if (dados.erro) {
                mostrarToast("CEP não encontrado.");
                return;
            }

            if (document.getElementById("rua")) document.getElementById("rua").value = dados.logradouro || "";
            if (document.getElementById("bairro")) document.getElementById("bairro").value = dados.bairro || "";
            if (document.getElementById("cidade")) document.getElementById("cidade").value = dados.localidade || "";
            if (document.getElementById("uf")) document.getElementById("uf").value = dados.uf || "";
        } catch {
            mostrarToast("Erro ao consultar o CEP.");
        }
    });
}

function mascaraTelefone(idCampo) {
    const campo = document.getElementById(idCampo);
    if (!campo) return;
    campo.addEventListener("input", () => {
        let valor = campo.value.replace(/\D/g, "").substring(0, 11);
        if (valor.length > 10) {
            valor = `(${valor.substring(0, 2)}) ${valor.substring(2, 7)}-${valor.substring(7)}`;
        } else if (valor.length > 6) {
            valor = `(${valor.substring(0, 2)}) ${valor.substring(2, 6)}-${valor.substring(6)}`;
        } else if (valor.length > 2) {
            valor = `(${valor.substring(0, 2)}) ${valor.substring(2)}`;
        }
        campo.value = valor;
    });
}
mascaraTelefone("telefone");
mascaraTelefone("celular");

/* Form Submit */
if (form) {
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        try {
            const nome = document.getElementById("nome").value.trim();
            const email = document.getElementById("email").value.trim().toLowerCase();
            const cpf = document.getElementById("cpf").value.trim();
            const cep = document.getElementById("cep").value.trim();
            const rua = document.getElementById("rua").value.trim();
            const bairro = document.getElementById("bairro").value.trim();
            const numero = document.getElementById("numero").value.trim();
            const complemento = document.getElementById("complemento").value.trim();
            const cidade = document.getElementById("cidade").value.trim(); // CORRIGIDO: de city para cidade
            const uf = document.getElementById("uf").value.trim();
            const telefone = document.getElementById("telefone").value.trim();
            const celular = document.getElementById("celular").value.trim();
            const login = document.getElementById("login").value.trim();
            const senha = document.getElementById("senha").value.trim();
            const confirmarSenha = document.getElementById("confirmarSenha").value.trim();

            /* Validações */
            if (!validarNome(nome)) {
                mostrarToast("O nome deve conter entre 15 e 80 caracteres (apenas letras).");
                return;
            }

            if (!validarEmail(email)) {
                mostrarToast("Por favor, insira um formato de e-mail válido.");
                return;
            }

            if (!validarCPF(cpf)) {
                mostrarToast("Por favor, informe um CPF válido.");
                return;
            }

            if (!/^[A-Za-z0-9]{3,15}$/.test(login)) {
                mostrarToast("O login deve possuir entre 3 e 15 caracteres (apenas letras e números).");
                return;
            }

            if (senha.length < 8 || senha.length > 20) {
                mostrarToast("A senha deve possuir entre 8 e 20 caracteres.");
                return;
            }

            if (senha !== confirmarSenha) {
                mostrarToast("A confirmação da senha não bate.");
                return;
            }

            const usuarios = JSON.parse(localStorage.getItem("usuariosCDKLS")) || [];

            const existeLogin = usuarios.find(u => u.login === login);
            if (existeLogin) {
                mostrarToast("Este login já está cadastrado por outro usuário.");
                return;
            }

            const existeEmail = usuarios.find(u => u.email === email);
            if (existeEmail) {
                mostrarToast("Este e-mail já está em uso por outra conta.");
                return;
            }

            const novoUsuario = {
                nome,
                email,
                cpf,
                cep,
                rua,
                bairro,
                numero,
                complemento,
                cidade,
                uf,
                telefone,
                celular,
                login,
                senha
            };

            usuarios.push(novoUsuario);
            localStorage.setItem("usuariosCDKLS", JSON.stringify(usuarios));

            mostrarToast("Cadastro realizado com sucesso!", "sucesso");
            form.reset();

            setTimeout(() => {
                window.location.href = "login.html";
            }, 2000);

        } catch (erro) {
            console.error("Erro interno no cadastro:", erro);
            mostrarToast("Erro ao processar cadastro. Verifique os campos.");
        }
    });
}