/* ===========================================
   CDKL's - Pagamento e Resumo
=========================================== */

const sessao = JSON.parse(localStorage.getItem("sessaoCDKLS"));

if (!sessao) {
    window.location.href = "login.html";
}

let carrinho = JSON.parse(localStorage.getItem("carrinhoCDKLS")) || [];

const forma = document.getElementById("forma");
const dadosCartao = document.getElementById("dadosCartao");
const form = document.getElementById("formPagamento");
const toast = document.getElementById("toast");
const listaResumo = document.getElementById("listaResumo");
const totalResumo = document.getElementById("totalResumo");

// NOVAS VARIÁVEIS DO PIX (Mapeando os elementos do HTML)
const dadosPix = document.getElementById("dadosPix");
const btnCopiarPix = document.getElementById("btnCopiarPix");
const pixChave = document.getElementById("pixChave");

// Configuração inicial das divs ocultas
dadosCartao.style.display = "none";
dadosPix.style.display = "none";

/* ===========================================
   CONTROLE DE EXIBIÇÃO DAS FORMAS DE PAGAMENTO
=========================================== */
forma.addEventListener("change", () => {
    if (forma.value === "Cartão de Crédito") {
        dadosCartao.style.display = "block";
        dadosPix.style.display = "none";
        configurarCamposCartao(true);
    } else if (forma.value === "Pix") {
        dadosCartao.style.display = "none";
        dadosPix.style.display = "block";
        configurarCamposCartao(false);
    } else {
        // Boleto Bancário
        dadosCartao.style.display = "none";
        dadosPix.style.display = "none";
        configurarCamposCartao(false);
    }
});

// Ativa ou desativa a obrigatoriedade dos campos ocultos do cartão
function configurarCamposCartao(obrigatorio) {
    document.getElementById("numeroCartao").required = obrigatorio;
    document.getElementById("validade").required = obrigatorio;
    document.getElementById("cvv").required = obrigatorio;
}

/* ===========================================
   BOTÃO COPIAR PIX COPIA E COLA
=========================================== */
btnCopiarPix.addEventListener("click", () => {
    pixChave.select();
    pixChave.setSelectionRange(0, 99999); // Para garantir funcionamento em celulares

    navigator.clipboard.writeText(pixChave.value)
        .then(() => {
            mostrarToast("Código Pix copiado com sucesso!", "sucesso");
        })
        .catch(() => {
            mostrarToast("Erro ao copiar o código.", "erro");
        });
});

/* ===========================================
   TOAST NOTIFICAÇÃO
=========================================== */
function mostrarToast(msg, tipo = "sucesso") {
    toast.textContent = msg;
    toast.className = "toast " + tipo;
    setTimeout(() => {
        toast.className = "toast";
        toast.textContent = "";
    }, 3000);
}

if (sessao) {
    document.getElementById("nome").value = sessao.nome;
}

/* ===========================================
   MÁSCARAS EM TEMPO REAL (CPF E CARTÃO)
=========================================== */
const cpfInput = document.getElementById("cpf");
cpfInput.addEventListener("input", () => {
    let valor = cpfInput.value.replace(/\D/g, "");
    valor = valor.substring(0, 11);
    valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
    valor = valor.replace(/(\d{3})(\d)/, "$1.$2");
    valor = valor.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    cpfInput.value = valor;
});

const numeroCartaoInput = document.getElementById("numeroCartao");
numeroCartaoInput.addEventListener("input", () => {
    let valor = numeroCartaoInput.value.replace(/\D/g, "");
    valor = valor.substring(0, 16);
    valor = valor.replace(/(\d{4})(?=\d)/g, "$1 ");
    numeroCartaoInput.value = valor;
});

const validadeInput = document.getElementById("validade");
validadeInput.addEventListener("input", () => {
    let valor = validadeInput.value.replace(/\D/g, "");
    valor = valor.substring(0, 4);
    if (valor.length > 2) {
        valor = valor.substring(0, 2) + "/" + valor.substring(2);
    }
    validadeInput.value = valor;
});

const cvvInput = document.getElementById("cvv");
cvvInput.addEventListener("input", () => {
    cvvInput.value = cvvInput.value.replace(/\D/g, "").substring(0, 4);
});

/* ===========================================
   FUNÇÕES DE VALIDAÇÃO TÉCNICA
=========================================== */
function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, "");
    if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
    
    let soma = 0;
    for (let i = 0; i < 9; i++) soma += Number(cpf.charAt(i)) * (10 - i);
    let resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== Number(cpf.charAt(9))) return false;
    
    soma = 0;
    for (let i = 0; i < 10; i++) soma += Number(cpf.charAt(i)) * (11 - i);
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    return resto === Number(cpf.charAt(10));
}

function validarValidadeCartao(validade) {
    if (!/^\d{2}\/\d{2}$/.test(validade)) return false;
    
    const partes = validade.split("/");
    const mes = parseInt(partes[0], 10);
    const ano = parseInt("20" + partes[1], 10);
    
    if (mes < 1 || mes > 12) return false;
    
    const dataAtual = new Date();
    const anoAtual = dataAtual.getFullYear();
    const mesAtual = dataAtual.getMonth() + 1;
    
    if (ano < anoAtual || (ano === anoAtual && mes < mesAtual)) {
        return false;
    }
    return true;
}

/* ===========================================
   PROCESSAMENTO DO RESUMO DO PEDIDO (FORÇA BRUTA)
=========================================== */
let soma = 0;
listaResumo.innerHTML = "";

carrinho.forEach(produto => {
    let preco = produto.preco;
    
    if (typeof preco === "string") {
        // 1. Limpa os caracteres básicos
        preco = Number(
            preco
                .replace("R$", "")
                .replace(/\s/g, "")
                .replace(/\./g, "")
                .replace(",", ".")
                .trim()
        );
    } else {
        preco = Number(preco);
    }

    if (preco >= 1000) {
        preco = preco / 100;
    }

    const quantidade = Number(produto.quantidade);
    const subtotalCalculado = preco * quantidade;
    soma += subtotalCalculado;

    listaResumo.innerHTML += `
        <div class="resumoItem" style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span>${produto.nome} <strong>(x${quantidade})</strong></span>
            <span>${subtotalCalculado.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</span>
        </div>
    `;
});

totalResumo.textContent = soma.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/* ===========================================
   ENVIO E PROCESSAMENTO DO FORMULÁRIO
=========================================== */
form.addEventListener("submit", (e) => {
    e.preventDefault();

    if (carrinho.length === 0) {
        mostrarToast("Seu carrinho está vazio.", "erro");
        return;
    }

    const cpfVal = document.getElementById("cpf").value;
    if (!validarCPF(cpfVal)) {
        mostrarToast("CPF digitado é inválido.", "erro");
        return;
    }

    if (forma.value === "Cartão de Crédito") {
        const numero = document.getElementById("numeroCartao").value.replace(/\s/g, "");
        const validade = document.getElementById("validade").value.trim();
        const cvv = document.getElementById("cvv").value.trim();

        if (numero.length < 13 || numero.length > 16) {
            mostrarToast("Número de cartão inválido.", "erro");
            return;
        }

        if (!validarValidadeCartao(validade)) {
            mostrarToast("Validade do cartão incorreta ou expirada.", "erro");
            return;
        }

        if (cvv.length < 3) {
            mostrarToast("Código CVV inválido.", "erro");
            return;
        }
    }

    // Sucesso na transação simulada
    localStorage.removeItem("carrinhoCDKLS");
    carrinho = [];

    mostrarToast("Pagamento realizado com sucesso!", "sucesso");

    setTimeout(() => {
        window.location.href = "index.html";
    }, 2000);
});