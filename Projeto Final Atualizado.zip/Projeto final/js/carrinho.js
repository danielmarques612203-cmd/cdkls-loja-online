/* ===========================================
   CDKL's - Carrinho de Compras
=========================================== */

// 1. Controle de Acessibilidade (Sincronização da Fonte)
const tamanhoFonte = Number(localStorage.getItem("fonteCDKLS")) || 16;
document.documentElement.style.fontSize = tamanhoFonte + "px";

// 2. Proteção de Rota
const sessao = JSON.parse(localStorage.getItem("sessaoCDKLS"));
if (!sessao) {
    window.location.href = "login.html";
}

const lista = document.getElementById("listaCarrinho");
const total = document.getElementById("valorTotal");

let carrinho = JSON.parse(localStorage.getItem("carrinhoCDKLS")) || [];

function salvarCarrinho() {
    localStorage.setItem("carrinhoCDKLS", JSON.stringify(carrinho));
}

function atualizarCarrinho() {
    let soma = 0;
    let htmlAcumulado = ""; 

    if (carrinho.length === 0) {
        lista.innerHTML = `
            <div class="item">
                <div class="info">
                    <h3>Seu carrinho está vazio.</h3>
                </div>
            </div>
        `;
        total.textContent = "R$ 0,00";
        return;
    }

    carrinho.forEach((produto, indice) => {
        let preco = produto.preco;

        // CORREÇÃO: Tratamento rigoroso apenas se o preço for String de texto
        if (typeof preco === "string") {
            // Se tiver o padrão brasileiro (ex: 1.250,90), limpa o ponto de milhar e troca a vírgula por ponto
            if (preco.includes(",")) {
                preco = preco.replace("R$", "").replace(/\./g, "").replace(",", ".").trim();
            } else {
                // Se for um texto simples sem vírgula (ex: "189"), apenas remove o cifrão
                preco = preco.replace("R$", "").trim();
            }
        }
        
        // Garante a conversão final para tipo numérico float puro
        preco = parseFloat(preco) || 0;

        const quantidade = Number(produto.quantidade) || 1;
        const subtotal = preco * quantidade;
        soma += subtotal;

        // Acumula a renderização estrutural
        htmlAcumulado += `
            <div class="item">
                <img 
                    src="${produto.imagem || 'img/sem-foto.jpg'}" 
                    alt="${produto.nome}"
                    onerror="this.src='img/sem-foto.jpg';"
                >
                <div class="info">
                    <h3>${produto.nome}</h3>
                    <p>
                        ${preco.toLocaleString("pt-BR", {
                            style: "currency",
                            currency: "BRL"
                        })}
                    </p>
                    <strong>
                        Quantidade: ${quantidade}
                    </strong>
                </div>
                <div class="acoes">
                    <button onclick="diminuir(${indice})">-</button>
                    <button onclick="aumentar(${indice})">+</button>
                    <button onclick="remover(${indice})">🗑</button>
                </div>
            </div>
        `;
    });

    lista.innerHTML = htmlAcumulado;

    // Renderiza o valor total corrigido e sem saltar para milhares
    total.textContent = soma.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

/* ===========================================
   CONTROLES DO CARRINHO
=========================================== */
function aumentar(indice) {
    carrinho[indice].quantidade++;
    salvarCarrinho();
    atualizarCarrinho();
}

function disminuir(indice) {
    carrinho[indice].quantidade--;

    if (carrinho[indice].quantidade <= 0) {
        carrinho.splice(indice, 1);
    }

    salvarCarrinho();
    atualizarCarrinho();
}

function remover(indice) {
    carrinho.splice(indice, 1);
    salvarCarrinho();
    atualizarCarrinho();
}

// Inicialização imediata
atualizarCarrinho();